package com.jsp;

public class JspDemo {
	
	public static String makecode(String code) {
		return code.toLowerCase();
		
	}

}
